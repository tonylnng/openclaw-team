#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

requires_docker() {
  case "${1:-}" in
    build|up|down|restart|ps|logs|shell|health|backup)
      return 0
      ;;
    *)
      return 1
      ;;
  esac
}

docker_permission_hint() {
  local user_name
  user_name="$(id -un)"

  cat >&2 <<EOF
Docker is installed, but the current user cannot access the Docker daemon.

Current user:
  ${user_name}

Recommended fix:
  sudo usermod -aG docker ${user_name}
  newgrp docker

Then verify:
  docker ps

If it still fails, log out of SSH, log back in, and retry:
  ./scripts/openclaw.sh build

Temporary workaround:
  sudo ./scripts/openclaw.sh ${cmd:-build}
EOF
}

preflight_docker_access() {
  if ! command -v docker >/dev/null 2>&1; then
    cat >&2 <<'EOF'
Docker is not installed or is not in PATH.

Install Docker first:
  chmod +x scripts/install-docker-ubuntu.sh
  ./scripts/install-docker-ubuntu.sh
  newgrp docker
EOF
    exit 127
  fi

  if [[ ! -S /var/run/docker.sock ]]; then
    cat >&2 <<'EOF'
Docker socket was not found at /var/run/docker.sock.

Check whether Docker is running:
  sudo systemctl status docker

Start Docker:
  sudo systemctl enable --now docker
EOF
    exit 1
  fi

  if ! id -nG | tr ' ' '\n' | grep -qx docker && [[ "${EUID}" -ne 0 ]]; then
    docker_permission_hint
    exit 13
  fi

  if ! docker ps >/dev/null 2>&1; then
    docker_permission_hint
    exit 13
  fi
}

compose() {
  cd "${ROOT_DIR}"
  export COMPOSE_PROJECT_NAME="${COMPOSE_PROJECT_NAME:-openclaw}"

  if docker compose version >/dev/null 2>&1; then
    docker compose "$@"
    return
  fi

  if command -v docker-compose >/dev/null 2>&1; then
    docker-compose "$@"
    return
  fi

  echo "Docker Compose is not available." >&2
  echo "Install the Docker Compose plugin or legacy docker-compose, then retry." >&2
  exit 127
}

usage() {
  cat <<'EOF'
OpenClaw Docker helper

Usage:
  scripts/openclaw.sh init
  scripts/openclaw.sh build
  scripts/openclaw.sh up
  scripts/openclaw.sh down
  scripts/openclaw.sh restart
  scripts/openclaw.sh ps
  scripts/openclaw.sh logs [service]
  scripts/openclaw.sh shell <role>
  scripts/openclaw.sh health
  scripts/openclaw.sh backup

Roles:
  architect designer developer qc operator pa
EOF
}

service_name() {
  local role="${1:-}"
  case "${role}" in
    architect|designer|developer|qc|operator|pa)
      printf 'openclaw-%s\n' "${role}"
      ;;
    openclaw-architect|openclaw-designer|openclaw-developer|openclaw-qc|openclaw-operator|openclaw-pa)
      printf '%s\n' "${role}"
      ;;
    *)
      echo "Unknown role: ${role}" >&2
      usage >&2
      exit 2
      ;;
  esac
}

cmd="${1:-}"
shift || true

if requires_docker "${cmd}"; then
  preflight_docker_access
fi

case "${cmd}" in
  init)
    if [[ ! -f "${ROOT_DIR}/.env" ]]; then
      cp "${ROOT_DIR}/.env.example" "${ROOT_DIR}/.env"
      echo "Created .env from .env.example"
    else
      echo ".env already exists"
    fi
    ;;
  build)
    compose build
    ;;
  up)
    compose up -d
    ;;
  down)
    compose down
    ;;
  restart)
    compose restart
    ;;
  ps)
    compose ps
    ;;
  logs)
    if [[ $# -gt 0 ]]; then
      compose logs -f "$(service_name "$1")"
    else
      compose logs -f
    fi
    ;;
  shell)
    if [[ $# -lt 1 ]]; then
      echo "Missing role." >&2
      usage >&2
      exit 2
    fi
    compose exec --user openclaw "$(service_name "$1")" bash -l
    ;;
  health)
    compose ps
    echo
    for role in architect designer developer qc operator pa; do
      service="$(service_name "${role}")"
      echo "== ${service} =="
      compose exec -T "${service}" bash -lc 'whoami; hostname; test -d /workspace/role; test -d /workspace/shared; echo "workspace ok"'
    done
    ;;
  backup)
    backup_dir="${ROOT_DIR}/backups"
    mkdir -p "${backup_dir}"
    stamp="$(date +%Y%m%d-%H%M%S)"
    archive="${backup_dir}/openclaw-volumes-${stamp}.tar.gz"
    docker run --rm \
      -v openclaw_openclaw_shared:/volumes/openclaw_shared:ro \
      -v openclaw_openclaw_architect:/volumes/openclaw_architect:ro \
      -v openclaw_openclaw_designer:/volumes/openclaw_designer:ro \
      -v openclaw_openclaw_developer:/volumes/openclaw_developer:ro \
      -v openclaw_openclaw_qc:/volumes/openclaw_qc:ro \
      -v openclaw_openclaw_operator:/volumes/openclaw_operator:ro \
      -v openclaw_openclaw_pa:/volumes/openclaw_pa:ro \
      -v "${backup_dir}:/backup" \
      ubuntu:24.04 \
      tar -czf "/backup/$(basename "${archive}")" -C /volumes .
    echo "Backup written to ${archive}"
    ;;
  ""|-h|--help|help)
    usage
    ;;
  *)
    echo "Unknown command: ${cmd}" >&2
    usage >&2
    exit 2
    ;;
esac
