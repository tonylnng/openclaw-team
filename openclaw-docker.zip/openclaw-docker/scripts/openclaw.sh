#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
COMPOSE=(docker compose --project-directory "${ROOT_DIR}")

usage() {
  cat <<'EOF'
OpenClaw Docker helper

Usage:
  scripts/openclaw.sh init
  scripts/openclaw.sh build
  scripts/openclaw.sh up
  scripts/openclaw.sh down
  scripts/openclaw.sh restart
  scripts/openclaw.sh ps
  scripts/openclaw.sh logs [service]
  scripts/openclaw.sh shell <role>
  scripts/openclaw.sh health
  scripts/openclaw.sh backup

Roles:
  architect designer developer qc operator pa
EOF
}

service_name() {
  local role="${1:-}"
  case "${role}" in
    architect|designer|developer|qc|operator|pa)
      printf 'openclaw-%s\n' "${role}"
      ;;
    openclaw-architect|openclaw-designer|openclaw-developer|openclaw-qc|openclaw-operator|openclaw-pa)
      printf '%s\n' "${role}"
      ;;
    *)
      echo "Unknown role: ${role}" >&2
      usage >&2
      exit 2
      ;;
  esac
}

cmd="${1:-}"
shift || true

case "${cmd}" in
  init)
    if [[ ! -f "${ROOT_DIR}/.env" ]]; then
      cp "${ROOT_DIR}/.env.example" "${ROOT_DIR}/.env"
      echo "Created .env from .env.example"
    else
      echo ".env already exists"
    fi
    ;;
  build)
    "${COMPOSE[@]}" build
    ;;
  up)
    "${COMPOSE[@]}" up -d
    ;;
  down)
    "${COMPOSE[@]}" down
    ;;
  restart)
    "${COMPOSE[@]}" restart
    ;;
  ps)
    "${COMPOSE[@]}" ps
    ;;
  logs)
    if [[ $# -gt 0 ]]; then
      "${COMPOSE[@]}" logs -f "$(service_name "$1")"
    else
      "${COMPOSE[@]}" logs -f
    fi
    ;;
  shell)
    if [[ $# -lt 1 ]]; then
      echo "Missing role." >&2
      usage >&2
      exit 2
    fi
    "${COMPOSE[@]}" exec --user openclaw "$(service_name "$1")" bash -l
    ;;
  health)
    "${COMPOSE[@]}" ps
    echo
    for role in architect designer developer qc operator pa; do
      service="$(service_name "${role}")"
      echo "== ${service} =="
      "${COMPOSE[@]}" exec -T "${service}" bash -lc 'whoami; hostname; test -d /workspace/role; test -d /workspace/shared; echo "workspace ok"'
    done
    ;;
  backup)
    backup_dir="${ROOT_DIR}/backups"
    mkdir -p "${backup_dir}"
    stamp="$(date +%Y%m%d-%H%M%S)"
    archive="${backup_dir}/openclaw-volumes-${stamp}.tar.gz"
    docker run --rm \
      -v openclaw_openclaw_shared:/volumes/openclaw_shared:ro \
      -v openclaw_openclaw_architect:/volumes/openclaw_architect:ro \
      -v openclaw_openclaw_designer:/volumes/openclaw_designer:ro \
      -v openclaw_openclaw_developer:/volumes/openclaw_developer:ro \
      -v openclaw_openclaw_qc:/volumes/openclaw_qc:ro \
      -v openclaw_openclaw_operator:/volumes/openclaw_operator:ro \
      -v openclaw_openclaw_pa:/volumes/openclaw_pa:ro \
      -v "${backup_dir}:/backup" \
      ubuntu:24.04 \
      tar -czf "/backup/$(basename "${archive}")" -C /volumes .
    echo "Backup written to ${archive}"
    ;;
  ""|-h|--help|help)
    usage
    ;;
  *)
    echo "Unknown command: ${cmd}" >&2
    usage >&2
    exit 2
    ;;
esac
