export OPENCLAW_ROLE_PROMPT="Quality control, test planning, validation, release gate management"
