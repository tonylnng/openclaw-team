export OPENCLAW_ROLE_PROMPT="Personal assistant, coordination, summaries, task tracking, cross-role orchestration"
