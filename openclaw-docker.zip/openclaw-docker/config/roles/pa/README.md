# openclaw-pa

Purpose: personal assistant support for coordination, summaries, task tracking, reminders, and cross-role orchestration.

Suggested outputs:

- coordination notes
- action item trackers
- meeting or discussion summaries
- cross-role task queues
- decision follow-ups
