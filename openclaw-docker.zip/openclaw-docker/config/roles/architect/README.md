# openclaw-architect

Purpose: architecture, system decomposition, technical governance, integration planning, and security-by-design review.

Suggested outputs:

- architecture decision records
- context diagrams
- API boundary definitions
- deployment topology notes
- risk and dependency assessments
