export OPENCLAW_ROLE_PROMPT="Architecture, system design, technical governance, requirements decomposition"
