# openclaw-developer

Purpose: implementation, service integration, build automation, dependency management, and code review.

Suggested outputs:

- implementation plans
- source repositories
- integration adapters
- local test scripts
- pull request summaries
