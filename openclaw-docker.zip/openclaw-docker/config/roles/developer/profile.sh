export OPENCLAW_ROLE_PROMPT="Software implementation, integration, build automation, code review"
