# openclaw-designer

Purpose: UX flows, UI specifications, interaction design, product prototypes, and user-facing documentation.

Suggested outputs:

- user journeys
- wireframe notes
- UI acceptance criteria
- design tokens
- usability review notes
