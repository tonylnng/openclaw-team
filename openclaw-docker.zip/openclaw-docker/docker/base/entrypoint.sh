#!/usr/bin/env bash
set -euo pipefail

ROLE="${OPENCLAW_ROLE:-unknown}"
ROLE_DESCRIPTION="${OPENCLAW_ROLE_DESCRIPTION:-OpenClaw role container}"
ENABLE_SSH="${ENABLE_SSH:-false}"

mkdir -p /run/sshd /workspace/role /workspace/shared
chown -R openclaw:openclaw /workspace

if [[ -f /opt/openclaw/role/README.md && ! -f /workspace/role/README.md ]]; then
  cp /opt/openclaw/role/README.md /workspace/role/README.md
  chown openclaw:openclaw /workspace/role/README.md
fi

if [[ -f /opt/openclaw/role/profile.sh ]]; then
  cp /opt/openclaw/role/profile.sh "/etc/profile.d/openclaw-${ROLE}.sh"
fi

cat > /etc/motd <<EOF
OpenClaw Ubuntu Agent
Role: ${ROLE}
Description: ${ROLE_DESCRIPTION}

Role workspace:   /workspace/role
Shared workspace: /workspace/shared
Role config:      /opt/openclaw/role
Bootstrap:        /opt/openclaw/bootstrap
EOF

if [[ "${ENABLE_SSH}" == "true" ]]; then
  mkdir -p /home/openclaw/.ssh
  chmod 700 /home/openclaw/.ssh
  if [[ -s /opt/openclaw/ssh/authorized_keys ]]; then
    cp /opt/openclaw/ssh/authorized_keys /home/openclaw/.ssh/authorized_keys
    chmod 600 /home/openclaw/.ssh/authorized_keys
    chown -R openclaw:openclaw /home/openclaw/.ssh
  fi
  if [[ ! -f /etc/ssh/ssh_host_rsa_key ]]; then
    ssh-keygen -A
  fi
  /usr/sbin/sshd
fi

exec "$@"
