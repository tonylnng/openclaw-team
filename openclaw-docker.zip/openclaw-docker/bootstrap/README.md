# Bootstrap directory

Put shared bootstrap assets here, for example:

- common shell profiles
- trusted internal CA certificates
- OpenClaw gateway configuration templates
- AI agent prompt libraries
- reusable scripts shared by all six role containers

This directory is mounted read-only at `/opt/openclaw/bootstrap` inside every container.
