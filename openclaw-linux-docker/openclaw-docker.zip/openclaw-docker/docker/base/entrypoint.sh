#!/usr/bin/env bash
set -euo pipefail

ROLE="${OPENCLAW_ROLE:-unknown}"
ROLE_DESCRIPTION="${OPENCLAW_ROLE_DESCRIPTION:-OpenClaw role container}"
ENABLE_SSH="${ENABLE_SSH:-false}"
ENABLE_GATEWAY="${ENABLE_GATEWAY:-true}"
GATEWAY_PORT="${OPENCLAW_GATEWAY_PORT:-18789}"

mkdir -p /run/sshd /workspace/role /workspace/shared /var/log/openclaw
chown -R openclaw:openclaw /workspace /var/log/openclaw

# Per-role isolated OpenClaw profile dir: ~/.openclaw-<role>
# This keeps each role's config, sessions, secrets, and cron jobs separate.
PROFILE_DIR="/home/openclaw/.openclaw-${ROLE}"
mkdir -p "${PROFILE_DIR}"
chown -R openclaw:openclaw "${PROFILE_DIR}"

if [[ -f /opt/openclaw/role/README.md && ! -f /workspace/role/README.md ]]; then
  cp /opt/openclaw/role/README.md /workspace/role/README.md
  chown openclaw:openclaw /workspace/role/README.md
fi

if [[ -f /opt/openclaw/role/profile.sh ]]; then
  cp /opt/openclaw/role/profile.sh "/etc/profile.d/openclaw-${ROLE}.sh"
fi

cat > /etc/motd <<EOF
OpenClaw Ubuntu Agent
Role:             ${ROLE}
Description:      ${ROLE_DESCRIPTION}
OpenClaw profile: ${PROFILE_DIR}  (use: openclaw --profile ${ROLE} ...)
Gateway:          $( [[ "${ENABLE_GATEWAY}" == "true" ]] && echo "enabled on port ${GATEWAY_PORT}" || echo "disabled" )

Role workspace:   /workspace/role
Shared workspace: /workspace/shared
Role config:      /opt/openclaw/role
Bootstrap:        /opt/openclaw/bootstrap
Gateway logs:     /var/log/openclaw/gateway.log
EOF

if [[ "${ENABLE_SSH}" == "true" ]]; then
  mkdir -p /home/openclaw/.ssh
  chmod 700 /home/openclaw/.ssh
  if [[ -s /opt/openclaw/ssh/authorized_keys ]]; then
    cp /opt/openclaw/ssh/authorized_keys /home/openclaw/.ssh/authorized_keys
    chmod 600 /home/openclaw/.ssh/authorized_keys
    chown -R openclaw:openclaw /home/openclaw/.ssh
  fi
  if [[ ! -f /etc/ssh/ssh_host_rsa_key ]]; then
    ssh-keygen -A
  fi
  /usr/sbin/sshd
fi

# --- Start the role-scoped OpenClaw gateway in the background ---------------
# Each role runs its own gateway under its own profile so they don't conflict.
# We do NOT make the gateway PID 1: the container keeps `sleep infinity` (or
# whatever CMD was passed) as PID 1, so an exec into the container always
# works even when the gateway is restarting or crashed.
if [[ "${ENABLE_GATEWAY}" == "true" && "${ROLE}" != "unknown" ]]; then
  if command -v openclaw >/dev/null 2>&1; then
    echo "[entrypoint] starting OpenClaw gateway for role=${ROLE} on port ${GATEWAY_PORT}"
    # Run as openclaw user, in the background, log to file
    su - openclaw -c "OPENCLAW_GATEWAY_PORT=${GATEWAY_PORT} \
        nohup openclaw --profile ${ROLE} gateway run \
        >> /var/log/openclaw/gateway.log 2>&1 &"
  else
    echo "[entrypoint] warning: 'openclaw' binary not found, skipping gateway start" >&2
  fi
fi

exec "$@"
