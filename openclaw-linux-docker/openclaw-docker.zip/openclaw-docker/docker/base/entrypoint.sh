#!/usr/bin/env bash
set -euo pipefail

ROLE="${OPENCLAW_ROLE:-unknown}"
ROLE_DESCRIPTION="${OPENCLAW_ROLE_DESCRIPTION:-OpenClaw role container}"
ENABLE_SSH="${ENABLE_SSH:-false}"
ENABLE_GATEWAY="${ENABLE_GATEWAY:-true}"
GATEWAY_PORT="${OPENCLAW_GATEWAY_PORT:-18789}"
GATEWAY_RESTART_DELAY="${OPENCLAW_GATEWAY_RESTART_DELAY:-5}"

mkdir -p /run/sshd /workspace/role /workspace/shared /var/log/openclaw /var/run/openclaw
# Pre-create the log files as the openclaw user so the watchdog (running as
# openclaw) can append to them. Without this, bash's `>>` redirect in the
# launch line below would create the file owned by root, and the watchdog
# would fail with `Permission denied` on every subsequent log write.
install -o openclaw -g openclaw -m 0644 /dev/null /var/log/openclaw/watchdog.log
install -o openclaw -g openclaw -m 0644 /dev/null /var/log/openclaw/gateway.log
chown -R openclaw:openclaw /workspace /var/log/openclaw /var/run/openclaw

# Per-role isolated OpenClaw profile dir: ~/.openclaw-<role>
PROFILE_DIR="/home/openclaw/.openclaw-${ROLE}"
mkdir -p "${PROFILE_DIR}"
chown -R openclaw:openclaw "${PROFILE_DIR}"

if [[ -f /opt/openclaw/role/README.md && ! -f /workspace/role/README.md ]]; then
  cp /opt/openclaw/role/README.md /workspace/role/README.md
  chown openclaw:openclaw /workspace/role/README.md
fi

if [[ -f /opt/openclaw/role/profile.sh ]]; then
  cp /opt/openclaw/role/profile.sh "/etc/profile.d/openclaw-${ROLE}.sh"
fi

cat > /etc/motd <<EOF
OpenClaw Ubuntu Agent
Role:             ${ROLE}
Description:      ${ROLE_DESCRIPTION}
OpenClaw profile: ${PROFILE_DIR}  (use: openclaw --profile ${ROLE} ...)
Gateway:          $( [[ "${ENABLE_GATEWAY}" == "true" ]] && echo "enabled on port ${GATEWAY_PORT}" || echo "disabled" )

Role workspace:   /workspace/role
Shared workspace: /workspace/shared
Role config:      /opt/openclaw/role
Bootstrap:        /opt/openclaw/bootstrap
Gateway logs:     /var/log/openclaw/gateway.log
Gateway PID:      /var/run/openclaw/gateway.pid
Watchdog log:     /var/log/openclaw/watchdog.log
EOF

if [[ "${ENABLE_SSH}" == "true" ]]; then
  mkdir -p /home/openclaw/.ssh
  chmod 700 /home/openclaw/.ssh
  if [[ -s /opt/openclaw/ssh/authorized_keys ]]; then
    cp /opt/openclaw/ssh/authorized_keys /home/openclaw/.ssh/authorized_keys
    chmod 600 /home/openclaw/.ssh/authorized_keys
    chown -R openclaw:openclaw /home/openclaw/.ssh
  fi
  if [[ ! -f /etc/ssh/ssh_host_rsa_key ]]; then
    ssh-keygen -A
  fi
  /usr/sbin/sshd
fi

# --- Start the role-scoped OpenClaw gateway with a watchdog ---------------
#
# Design:
# * The watchdog runs as the openclaw user, fully detached from this script
#   via setsid + nohup, in its own session and process group.
# * The watchdog loops forever: if the gateway exits for ANY reason, it
#   sleeps GATEWAY_RESTART_DELAY seconds and restarts it. This matches the
#   container-level `restart: unless-stopped` policy at the process level.
# * PID files let `openclaw.sh gateway restart` find and kill cleanly.
# * The watchdog itself survives entrypoint exit, so the gateway keeps
#   running (or auto-restarts) even after `exec sleep infinity` takes over.
# * If the gateway needs first-run config and crashes immediately, the
#   watchdog backs off but keeps trying — shell in and run
#   `openclaw --profile <role> doctor` to fix it; no rebuild needed.

if [[ "${ENABLE_GATEWAY}" == "true" && "${ROLE}" != "unknown" ]]; then
  if command -v openclaw >/dev/null 2>&1; then
    # Write the watchdog script as the openclaw user can read/execute it
    cat > /usr/local/bin/openclaw-gateway-watchdog <<'WATCHDOG'
#!/usr/bin/env bash
set -u

ROLE="${1:?role required}"
PORT="${2:?port required}"
RESTART_DELAY="${3:-5}"

LOG=/var/log/openclaw/gateway.log
WLOG=/var/log/openclaw/watchdog.log
GW_PID=/var/run/openclaw/gateway.pid
WD_PID=/var/run/openclaw/watchdog.pid

echo $$ > "${WD_PID}"

log() {
  echo "[$(date -u +%FT%TZ)] $*" >> "${WLOG}"
}

# Clean shutdown: if watchdog is killed, kill the gateway too.
on_term() {
  log "watchdog received TERM, stopping gateway"
  if [[ -f "${GW_PID}" ]] && kill -0 "$(cat "${GW_PID}")" 2>/dev/null; then
    kill -TERM "$(cat "${GW_PID}")" 2>/dev/null || true
    sleep 2
    kill -KILL "$(cat "${GW_PID}")" 2>/dev/null || true
  fi
  rm -f "${WD_PID}" "${GW_PID}"
  exit 0
}
trap on_term TERM INT

log "watchdog starting for role=${ROLE} port=${PORT} delay=${RESTART_DELAY}"

while true; do
  log "starting: openclaw --profile ${ROLE} gateway run (port ${PORT})"
  OPENCLAW_GATEWAY_PORT="${PORT}" \
    openclaw --profile "${ROLE}" gateway run \
    >> "${LOG}" 2>&1 &
  GW=$!
  echo "${GW}" > "${GW_PID}"
  log "gateway pid=${GW}"

  # Wait for the gateway. `wait` propagates its exit code.
  set +e
  wait "${GW}"
  RC=$?
  set -e
  log "gateway exited rc=${RC}"
  rm -f "${GW_PID}"

  # Backoff to avoid hot crash loop on misconfiguration.
  sleep "${RESTART_DELAY}"
done
WATCHDOG
    chmod 0755 /usr/local/bin/openclaw-gateway-watchdog

    echo "[entrypoint] starting OpenClaw gateway watchdog: role=${ROLE} port=${GATEWAY_PORT}"

    # Detach completely:
    #   * runuser switches user without spawning a login shell that captures the child
    #   * setsid puts the watchdog in its own session (no controlling TTY, immune to SIGHUP)
    #   * nohup is belt-and-suspenders against SIGHUP
    #   * </dev/null and >> redirections sever stdio from this script
    # Launch detached, with stdio severed and the log redirect performed by the
    # already-switched user (so the fd inherits openclaw's permissions, not root's).
    nohup setsid runuser -u openclaw -- bash -c \
      'exec /usr/local/bin/openclaw-gateway-watchdog "$1" "$2" "$3" \
         </dev/null >>/var/log/openclaw/watchdog.log 2>&1' \
      _ "${ROLE}" "${GATEWAY_PORT}" "${GATEWAY_RESTART_DELAY}" \
      </dev/null >/dev/null 2>&1 &
    disown || true

    # Sanity check: poll for the watchdog PID file (up to 10s) before giving up.
    # First-time starts can be slow because of npm/node init.
    WD_OK=0
    for i in 1 2 3 4 5 6 7 8 9 10; do
      if [[ -f /var/run/openclaw/watchdog.pid ]] \
          && kill -0 "$(cat /var/run/openclaw/watchdog.pid)" 2>/dev/null; then
        WD_OK=1
        break
      fi
      sleep 1
    done
    if [[ "${WD_OK}" -eq 1 ]]; then
      echo "[entrypoint] watchdog pid=$(cat /var/run/openclaw/watchdog.pid)"
    else
      echo "[entrypoint] WARNING: watchdog did not register PID after 10s; dumping watchdog.log:" >&2
      tail -n 50 /var/log/openclaw/watchdog.log >&2 || true
    fi
  else
    echo "[entrypoint] warning: 'openclaw' binary not found, skipping gateway start" >&2
  fi
fi

exec "$@"
