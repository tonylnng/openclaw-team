#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

requires_docker() {
  case "${1:-}" in
    build|up|down|restart|ps|logs|shell|health|backup|gateway)
      return 0
      ;;
    *)
      return 1
      ;;
  esac
}

docker_permission_hint() {
  local user_name
  user_name="$(id -un)"

  cat >&2 <<EOF
Docker is installed, but the current user cannot access the Docker daemon.

Current user:
  ${user_name}

Recommended fix:
  sudo usermod -aG docker ${user_name}
  newgrp docker

Then verify:
  docker ps

If it still fails, log out of SSH, log back in, and retry:
  ./scripts/openclaw.sh build

Temporary workaround:
  sudo ./scripts/openclaw.sh ${cmd:-build}
EOF
}

preflight_docker_access() {
  if ! command -v docker >/dev/null 2>&1; then
    cat >&2 <<'EOF'
Docker is not installed or is not in PATH.

Install Docker first:
  chmod +x scripts/install-docker-ubuntu.sh
  ./scripts/install-docker-ubuntu.sh
  newgrp docker
EOF
    exit 127
  fi

  if [[ ! -S /var/run/docker.sock ]]; then
    cat >&2 <<'EOF'
Docker socket was not found at /var/run/docker.sock.

Check whether Docker is running:
  sudo systemctl status docker

Start Docker:
  sudo systemctl enable --now docker
EOF
    exit 1
  fi

  if ! id -nG | tr ' ' '\n' | grep -qx docker && [[ "${EUID}" -ne 0 ]]; then
    docker_permission_hint
    exit 13
  fi

  if ! docker ps >/dev/null 2>&1; then
    docker_permission_hint
    exit 13
  fi
}

compose() {
  cd "${ROOT_DIR}"
  export COMPOSE_PROJECT_NAME="${COMPOSE_PROJECT_NAME:-openclaw}"

  if docker compose version >/dev/null 2>&1; then
    docker compose "$@"
    return
  fi

  if command -v docker-compose >/dev/null 2>&1; then
    docker-compose "$@"
    return
  fi

  echo "Docker Compose is not available." >&2
  echo "Install the Docker Compose plugin or legacy docker-compose, then retry." >&2
  exit 127
}

usage() {
  cat <<'EOF'
OpenClaw Docker helper

Usage:
  scripts/openclaw.sh init
  scripts/openclaw.sh build
  scripts/openclaw.sh up
  scripts/openclaw.sh down
  scripts/openclaw.sh restart
  scripts/openclaw.sh ps
  scripts/openclaw.sh logs [service]
  scripts/openclaw.sh shell <role>
  scripts/openclaw.sh health
  scripts/openclaw.sh backup
  scripts/openclaw.sh gateway status|logs|restart [role]
  scripts/openclaw.sh version

Roles:
  architect designer developer qc operator pa
EOF
}

service_name() {
  local role="${1:-}"
  case "${role}" in
    architect|designer|developer|qc|operator|pa)
      printf 'openclaw-%s\n' "${role}"
      ;;
    openclaw-architect|openclaw-designer|openclaw-developer|openclaw-qc|openclaw-operator|openclaw-pa)
      printf '%s\n' "${role}"
      ;;
    *)
      echo "Unknown role: ${role}" >&2
      usage >&2
      exit 2
      ;;
  esac
}

cmd="${1:-}"
shift || true

if requires_docker "${cmd}"; then
  preflight_docker_access
fi

case "${cmd}" in
  init)
    if [[ ! -f "${ROOT_DIR}/.env" ]]; then
      cp "${ROOT_DIR}/.env.example" "${ROOT_DIR}/.env"
      echo "Created .env from .env.example"
    else
      echo ".env already exists"
    fi
    ;;
  build)
    compose build
    ;;
  up)
    compose up -d
    ;;
  down)
    compose down
    ;;
  restart)
    compose restart
    ;;
  ps)
    compose ps
    ;;
  logs)
    if [[ $# -gt 0 ]]; then
      compose logs -f "$(service_name "$1")"
    else
      compose logs -f
    fi
    ;;
  shell)
    if [[ $# -lt 1 ]]; then
      echo "Missing role." >&2
      usage >&2
      exit 2
    fi
    compose exec --user openclaw "$(service_name "$1")" bash -l
    ;;
  health)
    compose ps
    echo
    for role in architect designer developer qc operator pa; do
      service="$(service_name "${role}")"
      echo "== ${service} =="
      compose exec -T "${service}" bash -lc 'whoami; hostname; test -d /workspace/role; test -d /workspace/shared; echo "workspace ok"; (nc -z 127.0.0.1 ${OPENCLAW_GATEWAY_PORT:-18789} && echo "gateway ok") || echo "gateway DOWN"'
    done
    ;;
  gateway)
    sub="${1:-status}"
    shift || true
    case "${sub}" in
      status)
        for role in architect designer developer qc operator pa; do
          service="$(service_name "${role}")"
          status="$(compose exec -T "${service}" bash -lc 'nc -z 127.0.0.1 ${OPENCLAW_GATEWAY_PORT:-18789} && echo UP || echo DOWN' 2>/dev/null || echo "ERR")"
          printf '%-22s %s\n' "${service}" "${status}"
        done
        ;;
      logs)
        if [[ $# -lt 1 ]]; then
          echo "Usage: scripts/openclaw.sh gateway logs <role>" >&2
          exit 2
        fi
        compose exec -T "$(service_name "$1")" tail -f /var/log/openclaw/gateway.log
        ;;
      restart)
        # Send SIGTERM to the gateway PID; the watchdog will respawn it.
        restart_one() {
          local svc="$1"
          echo "Restarting gateway in ${svc} (watchdog will respawn)..."
          compose exec -T "${svc}" bash -lc '
            if [[ -f /var/run/openclaw/gateway.pid ]] && kill -0 "$(cat /var/run/openclaw/gateway.pid)" 2>/dev/null; then
              kill -TERM "$(cat /var/run/openclaw/gateway.pid)" && echo "sent TERM to gateway pid=$(cat /var/run/openclaw/gateway.pid)"
            else
              echo "no live gateway pid; check /var/log/openclaw/watchdog.log" >&2
            fi'
        }
        if [[ $# -lt 1 ]]; then
          for role in architect designer developer qc operator pa; do
            restart_one "$(service_name "${role}")"
          done
        else
          restart_one "$(service_name "$1")"
        fi
        ;;
      *)
        echo "Unknown gateway subcommand: ${sub}" >&2
        echo "Usage: scripts/openclaw.sh gateway status|logs|restart [role]" >&2
        exit 2
        ;;
    esac
    ;;
  version)
    echo "OpenClaw Docker stack release: $(cat "${ROOT_DIR}/VERSION" 2>/dev/null || echo unknown)"
    if compose ps -q openclaw-developer >/dev/null 2>&1; then
      compose exec -T --user openclaw openclaw-developer bash -lc 'echo "node:     $(node --version)"; echo "npm:      $(npm --version)"; echo "openclaw: $(openclaw --version 2>/dev/null || echo not-installed)"'
    fi
    ;;
  backup)
    backup_dir="${ROOT_DIR}/backups"
    mkdir -p "${backup_dir}"
    stamp="$(date +%Y%m%d-%H%M%S)"
    archive="${backup_dir}/openclaw-volumes-${stamp}.tar.gz"
    docker run --rm \
      -v openclaw_openclaw_shared:/volumes/openclaw_shared:ro \
      -v openclaw_openclaw_architect:/volumes/openclaw_architect:ro \
      -v openclaw_openclaw_designer:/volumes/openclaw_designer:ro \
      -v openclaw_openclaw_developer:/volumes/openclaw_developer:ro \
      -v openclaw_openclaw_qc:/volumes/openclaw_qc:ro \
      -v openclaw_openclaw_operator:/volumes/openclaw_operator:ro \
      -v openclaw_openclaw_pa:/volumes/openclaw_pa:ro \
      -v openclaw_openclaw_profile_architect:/volumes/openclaw_profile_architect:ro \
      -v openclaw_openclaw_profile_designer:/volumes/openclaw_profile_designer:ro \
      -v openclaw_openclaw_profile_developer:/volumes/openclaw_profile_developer:ro \
      -v openclaw_openclaw_profile_qc:/volumes/openclaw_profile_qc:ro \
      -v openclaw_openclaw_profile_operator:/volumes/openclaw_profile_operator:ro \
      -v openclaw_openclaw_profile_pa:/volumes/openclaw_profile_pa:ro \
      -v "${backup_dir}:/backup" \
      ubuntu:24.04 \
      tar -czf "/backup/$(basename "${archive}")" -C /volumes .
    echo "Backup written to ${archive}"
    ;;
  ""|-h|--help|help)
    usage
    ;;
  *)
    echo "Unknown command: ${cmd}" >&2
    usage >&2
    exit 2
    ;;
esac
