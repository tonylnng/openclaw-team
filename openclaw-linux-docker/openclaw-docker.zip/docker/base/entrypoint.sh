#!/usr/bin/env bash
set -euo pipefail

ROLE="${OPENCLAW_ROLE:-unknown}"
ROLE_DESCRIPTION="${OPENCLAW_ROLE_DESCRIPTION:-OpenClaw role container}"
ENABLE_SSH="${ENABLE_SSH:-false}"
ENABLE_GATEWAY="${ENABLE_GATEWAY:-true}"

mkdir -p /run/sshd /workspace/role /workspace/shared /var/log/openclaw
chown -R openclaw:openclaw /workspace
# Logs are owned by root because the gateway also runs as root in 1.2.0+.
chmod 0755 /var/log/openclaw

# OpenClaw config dir (where `openclaw setup` writes openclaw.json).
# Mounted from a named volume in docker-compose.yml so it survives rebuilds.
mkdir -p /root/.openclaw

if [[ -f /opt/openclaw/role/README.md && ! -f /workspace/role/README.md ]]; then
  cp /opt/openclaw/role/README.md /workspace/role/README.md
  chown openclaw:openclaw /workspace/role/README.md
fi

if [[ -f /opt/openclaw/role/profile.sh ]]; then
  cp /opt/openclaw/role/profile.sh "/etc/profile.d/openclaw-${ROLE}.sh"
fi

cat > /etc/motd <<EOF
OpenClaw Ubuntu Agent
Role:             ${ROLE}
Description:      ${ROLE_DESCRIPTION}
Gateway:          $( [[ "${ENABLE_GATEWAY}" == "true" ]] && echo "auto-start enabled (port 18789)" || echo "disabled" )
Config dir:       /root/.openclaw  (run \`openclaw setup\` then \`openclaw configure\` once to populate)

Role workspace:   /workspace/role
Shared workspace: /workspace/shared
Role config:      /opt/openclaw/role
Bootstrap:        /opt/openclaw/bootstrap
Gateway log:      /var/log/openclaw/gateway.log
EOF

if [[ "${ENABLE_SSH}" == "true" ]]; then
  mkdir -p /home/openclaw/.ssh
  chmod 700 /home/openclaw/.ssh
  if [[ -s /opt/openclaw/ssh/authorized_keys ]]; then
    cp /opt/openclaw/ssh/authorized_keys /home/openclaw/.ssh/authorized_keys
    chmod 600 /home/openclaw/.ssh/authorized_keys
    chown -R openclaw:openclaw /home/openclaw/.ssh
  fi
  if [[ ! -f /etc/ssh/ssh_host_rsa_key ]]; then
    ssh-keygen -A
  fi
  /usr/sbin/sshd
fi

# --- Start OpenClaw gateway in the background ----------------------------
#
# 1.2.0 design: match exactly what works when run by hand.
#   * Run as root (the user `openclaw setup` writes config under /root/.openclaw).
#   * No `--profile` flag — each container has its own /root/.openclaw mounted
#     from a per-role named volume, so isolation is at the volume level.
#   * `setsid` detaches from the entrypoint's session so SIGHUP can't reach it.
#   * `nohup` is belt-and-suspenders against signals.
#   * Container CMD remains `sleep infinity` so a crashed gateway never takes
#     the container down — you can always shell in to fix config.
#
# If the gateway crashes after startup (e.g. config wiped, port conflict),
# `docker compose restart <role>` brings it back up.
# If you need the gateway to auto-restart on crash *within* a running container,
# wrap it in a small loop in this entrypoint or use a process supervisor; the
# 1.1.x watchdog approach was reverted here because it added complexity that
# wasn't needed for the actual user workflow.

# OpenClaw 2026.5.x writes config to /root/.openclaw/openclaw.json
# (NOT config.json — that was wrong in 1.2.0). Accept either name to
# tolerate a future CLI rename.
has_openclaw_config() {
  [[ -f /root/.openclaw/openclaw.json || -f /root/.openclaw/config.json ]]
}

if [[ "${ENABLE_GATEWAY}" == "true" ]]; then
  if command -v openclaw >/dev/null 2>&1; then
    if ! has_openclaw_config; then
      echo "[entrypoint] no OpenClaw config found in /root/.openclaw (looked for openclaw.json, config.json)"
      echo "[entrypoint] gateway will not start until first-run setup is complete:"
      echo "[entrypoint]   docker exec -it ${HOSTNAME} openclaw setup"
      echo "[entrypoint]   docker exec -it ${HOSTNAME} openclaw configure   # pick provider + API key"
      echo "[entrypoint] then: docker compose restart ${HOSTNAME}"
    else
      echo "[entrypoint] starting OpenClaw gateway (config: /root/.openclaw/openclaw.json)"
      nohup setsid openclaw gateway \
        </dev/null >>/var/log/openclaw/gateway.log 2>&1 &
      disown || true
      echo "[entrypoint] gateway launched in background; tail /var/log/openclaw/gateway.log to follow"
    fi
  else
    echo "[entrypoint] warning: 'openclaw' binary not found, skipping gateway start" >&2
  fi
fi

exec "$@"
